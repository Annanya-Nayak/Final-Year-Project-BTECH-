from collections import deque
import random
 
class ReplayBuffer:
    """
    Experience replay buffer for Q-learning.
    Stores (state, action, reward, next_state) tuples.
    Training on random batches breaks correlation between consecutive experiences.
    """
 
    def __init__(self, maxlen=5000, batch_size=32, train_every=50):
        self.buffer      = deque(maxlen=maxlen)  # Auto-drops oldest when full
        self.batch_size  = batch_size
        self.train_every = train_every           # Retrain every N experiences
        self._step_count = 0
 
    def push(self, state_idx, action, reward, next_state_idx):
        """Add one experience to the buffer."""
        self.buffer.append((state_idx, action, reward, next_state_idx))
        self._step_count += 1
 
    def should_train(self) -> bool:
        """Returns True every train_every steps if buffer has enough data."""
        return (
            self._step_count % self.train_every == 0
            and len(self.buffer) >= self.batch_size
        )
 
    def sample(self) -> list:
        """Random sample of batch_size experiences."""
        return random.sample(list(self.buffer), self.batch_size)
 
    def __len__(self): return len(self.buffer)
 
