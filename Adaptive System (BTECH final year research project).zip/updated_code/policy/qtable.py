"""
qtable.py — Double Q-Learning implementation.

Why Double Q-Learning?
    The original single Q-table suffers from maximisation bias: because
    argmax over noisy Q-values is used for both action selection AND target
    computation, Q-values are systematically overestimated (Hasselt, 2010).

    Double Q-Learning (van Hasselt et al., 2016 — DDQN) decouples these:
        • Q1 selects the greedy action  →  a* = argmax_a Q1(s,a)
        • Q2 evaluates that action      →  target = r + γ · Q2(s, a*)
    with the tables swapped randomly on alternate updates.

    For our contextual bandit (γ=0), the practical benefit is more stable
    reward estimates, which is especially important when sensitivity-specific
    sub-tables share very few visit counts per state.

Sensitivity-specific Q-tables:
    Each sensitivity level (low / medium / high) owns an independent
    DoubleQTable.  This eliminates cross-sensitivity generalisation error —
    the original bug that caused high-sensitivity requests to receive less
    post-quantum protection than low-sensitivity ones under heavy load.
"""

import numpy as np
import logging

logger = logging.getLogger(__name__)


class DoubleQTable:
    """
    Double Q-Learning table for a single sensitivity level.

    Attributes
    ----------
    ACTIONS      : ordered list of algorithm names
    N_ACTIONS    : number of possible actions (3)
    STATE_SIZE   : total discretised state count
    q1, q2       : twin Q-tables; action selection uses q1+q2 argmax
    alpha        : learning rate
    gamma        : discount (0 — contextual bandit)
    epsilon      : exploration probability (decays online)
    update_count : total Q-value updates so far
    """

    ACTIONS = ["classical", "hybrid", "post_quantum"]
    N_ACTIONS = 3

    # State discretisation boundaries
    CPU_BINS     = [0, 25, 50, 75, 100]
    LATENCY_BINS = [0, 30, 80, 150, 300]
    PAYLOAD_BINS = [0, 100, 500, 2000, 99_999]
    TREND_BINS   = [-100, -10, 10, 100]

    # 4 × 4 × 4 × 3 = 192 states per sensitivity level
    STATE_SIZE = 4 * 4 * 4 * 3

    def __init__(
        self,
        sensitivity_label: str,
        alpha: float = 0.1,
        gamma: float = 0.0,
        epsilon: float = 0.3,
        min_epsilon: float = 0.05,
        epsilon_decay: float = 0.999,
    ) -> None:
        self.sensitivity_label = sensitivity_label
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.min_epsilon = min_epsilon
        self.epsilon_decay = epsilon_decay
        self.update_count = 0

        rng = np.random.default_rng()
        init = dict(low=-0.01, high=0.01, size=(self.STATE_SIZE, self.N_ACTIONS))
        self.q1: np.ndarray = rng.uniform(**init)
        self.q2: np.ndarray = rng.uniform(**init)

    # ------------------------------------------------------------------
    # State encoding
    # ------------------------------------------------------------------

    def get_state_idx(
        self,
        cpu: float,
        latency: float,
        payload: int,
        trend: float,
    ) -> int:
        cpu_idx = int(min(np.digitize(cpu,     self.CPU_BINS[1:]),     3))
        lat_idx = int(min(np.digitize(latency, self.LATENCY_BINS[1:]), 3))
        pay_idx = int(min(np.digitize(payload, self.PAYLOAD_BINS[1:]), 3))
        trd_idx = int(min(np.digitize(trend,   self.TREND_BINS[1:]),   2))
        idx = (cpu_idx * 4 * 4 * 3) + (lat_idx * 4 * 3) + (pay_idx * 3) + trd_idx
        return int(min(idx, self.STATE_SIZE - 1))

    # ------------------------------------------------------------------
    # Action selection
    # ------------------------------------------------------------------

    def select_action(self, state_idx: int) -> int:
        """
        ε-greedy selection over the combined Q-table (Q1 + Q2).
        Using the sum reduces variance and retains the Double-Q property
        because updates alternate between the two tables independently.
        """
        if np.random.random() < self.epsilon:
            return int(np.random.randint(self.N_ACTIONS))
        self.epsilon = max(self.min_epsilon, self.epsilon * self.epsilon_decay)
        combined = self.q1[state_idx] + self.q2[state_idx]
        return int(np.argmax(combined))

    # ------------------------------------------------------------------
    # Update (Double Q-Learning)
    # ------------------------------------------------------------------

    def update(
        self,
        state_idx: int,
        action: int,
        reward: float,
        next_state_idx: int | None = None,
    ) -> None:
        """
        Double Q-Learning update (γ=0 contextual bandit variant).

        With probability 0.5:
            Update Q1:  a* = argmax_a Q1(s,·)
                        Q1(s,a) ← Q1(s,a) + α · (r - Q1(s,a))
        Otherwise:
            Update Q2:  Q2(s,a) ← Q2(s,a) + α · (r - Q2(s,a))

        Because γ=0 the next-state term vanishes; the Double-Q benefit here
        is purely in decoupled estimation, reducing overestimation of the
        best action's value and producing more stable per-sensitivity learning.
        """
        if np.random.random() < 0.5:
            current = self.q1[state_idx, action]
            self.q1[state_idx, action] = current + self.alpha * (reward - current)
        else:
            current = self.q2[state_idx, action]
            self.q2[state_idx, action] = current + self.alpha * (reward - current)
        self.update_count += 1

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def combined_values(self, state_idx: int) -> np.ndarray:
        """Return Q1+Q2 for a given state (for policy_stats / debugging)."""
        return self.q1[state_idx] + self.q2[state_idx]

    def best_action_label(self, state_idx: int) -> str:
        return self.ACTIONS[int(np.argmax(self.combined_values(state_idx)))]

    def __repr__(self) -> str:
        return (
            f"DoubleQTable(sensitivity={self.sensitivity_label!r}, "
            f"ε={self.epsilon:.4f}, updates={self.update_count})"
        )
